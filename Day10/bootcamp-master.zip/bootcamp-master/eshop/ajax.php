<?php 
	echo "ajax";

	// echo $_GET['a'] + $_GET['b'];

	echo $_POST['a'] + $_POST['b'];


?>