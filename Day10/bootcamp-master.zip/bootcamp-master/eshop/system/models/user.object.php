<?php

class eshop_user_object
{
  
}