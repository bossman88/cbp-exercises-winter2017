<?php

class eshop_product_object
{
  
}