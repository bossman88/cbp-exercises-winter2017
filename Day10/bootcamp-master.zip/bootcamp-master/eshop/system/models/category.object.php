<?php

class eshop_category_object
{
  
}