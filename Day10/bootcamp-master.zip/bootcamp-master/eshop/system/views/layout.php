<div id="page">

  <div id="header">
    <?php echo $header; ?>
  </div>



  <div id="topmenu">
    <?php echo $topmenu; ?>
  </div>



  <div id="content">
    <?php echo $content; ?>
  </div>




  <div id="footer">
    <?php echo $footer; ?>
  </div>

</div>