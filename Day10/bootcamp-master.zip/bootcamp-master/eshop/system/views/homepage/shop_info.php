<p>Shop with us! Don't try the competition! We are the best! <strong>Pleeeaaasee!</strong></p>

<div id="ajax-content"></div>
<button id="ajax-button">Ajax!</button>
<button id="ajax-button2">Ajax!</button>

