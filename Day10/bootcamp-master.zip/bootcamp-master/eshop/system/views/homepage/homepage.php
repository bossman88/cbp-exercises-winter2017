<div class="shop_info">
  <?php echo $shop_info; ?>
</div>

<div class="top_products">
  <?php echo $top_products; ?>
</div>

<div class="categories">
  <?php echo $categories; ?>
</div>

