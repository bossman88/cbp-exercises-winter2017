<h1><?php echo  $category['name']; ?></h1>
<p class="description"><?php echo $category['description']; ?></p>