<?php

class error404_controller
{
  public function run()
  {
    echo '<h1>ERROR 404</h1>';
  }

}