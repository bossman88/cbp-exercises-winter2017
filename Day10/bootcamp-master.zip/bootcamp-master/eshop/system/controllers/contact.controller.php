<?php

class contact_controller
{

  public function run()
  {
    
  }

}